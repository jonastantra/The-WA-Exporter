// Content Script for Snatch WhatsApp Exporter v2.2
// Versión simplificada y robusta - Diciembre 2025

console.log('🟢 Snatch Exporter: Content script cargado v2.2');

// ========================================
// Variables Globales
// ========================================
let isScanning = false;
let scanIntervalId = null;
let extractedContacts = new Map();

// ========================================
// FUNCIÓN PRINCIPAL: Encontrar Contenedor de Chats
// ========================================
function findChatContainer() {
    console.log('🔍 Buscando contenedor de chats...');
    
    // ESTRATEGIA 1: Selector principal #pane-side
    let container = document.querySelector('#pane-side');
    if (container) {
        // Buscar el div scrollable dentro de pane-side
        const scrollable = findScrollableChild(container);
        if (scrollable) {
            console.log('✅ Contenedor encontrado dentro de #pane-side');
            return scrollable;
        }
        // Si pane-side existe pero no es scrollable, puede ser el contenedor padre
        if (container.scrollHeight > 200) {
            console.log('✅ Contenedor encontrado: #pane-side');
            return container;
        }
    }
    
    // ESTRATEGIA 2: data-testid específicos
    const testIds = ['chat-list', 'pane-side', 'chatlist'];
    for (const id of testIds) {
        container = document.querySelector(`[data-testid="${id}"]`);
        if (container) {
            const scrollable = findScrollableChild(container) || container;
            if (scrollable.scrollHeight > 200) {
                console.log(`✅ Contenedor encontrado: [data-testid="${id}"]`);
                return scrollable;
            }
        }
    }
    
    // ESTRATEGIA 3: Buscar por estructura del DOM de WhatsApp/WhatsApp Business
    const appDiv = document.querySelector('#app');
    if (appDiv) {
        // Buscar el panel izquierdo (primer hijo grande con scroll)
        const panels = appDiv.querySelectorAll(':scope > div > div > div');
        for (const panel of panels) {
            const scrollable = findScrollableChild(panel);
            if (scrollable && scrollable.scrollHeight > 400) {
                const hasContactInfo = scrollable.querySelector('span[title], [data-testid*="cell"], img[src*="pps.whatsapp"]');
                if (hasContactInfo) {
                    console.log('✅ Contenedor encontrado via estructura DOM');
                    return scrollable;
                }
            }
        }
    }
    
    // ESTRATEGIA 4: role="grid", "list", "listbox"
    const roleContainers = document.querySelectorAll('div[role="grid"], div[role="list"], div[role="listbox"], div[role="application"]');
    for (const el of roleContainers) {
        const scrollable = findScrollableChild(el) || el;
        if (scrollable.scrollHeight > 300) {
            const hasItems = scrollable.querySelector('[role="listitem"], [role="row"], [role="option"], span[title]');
            if (hasItems) {
                console.log('✅ Contenedor encontrado via role');
                return scrollable;
            }
        }
    }
    
    // ESTRATEGIA 5: Búsqueda agresiva - cualquier div scrollable con contenido
    console.log('🔍 Búsqueda agresiva...');
    const allDivs = document.querySelectorAll('div');
    const candidates = [];
    
    for (const div of allDivs) {
        if (div.scrollHeight > 400 && div.clientHeight > 150) {
            const style = window.getComputedStyle(div);
            const hasScroll = div.scrollHeight > div.clientHeight + 50;
            const overflowOk = ['auto', 'scroll', 'overlay', 'hidden'].includes(style.overflowY);
            
            if (hasScroll && overflowOk) {
                // Verificar que tiene contenido de chats
                const hasSpanTitle = div.querySelector('span[title]');
                const hasImg = div.querySelector('img[src*="pps.whatsapp"], img[draggable="false"]');
                const hasText = div.innerText && div.innerText.length > 100;
                
                // Excluir panel de mensajes
                const isMessagePanel = div.querySelector('footer') || 
                                       div.querySelector('[data-testid="conversation-compose-box-input"]') ||
                                       div.querySelector('[contenteditable="true"]');
                
                if ((hasSpanTitle || hasImg || hasText) && !isMessagePanel) {
                    candidates.push({
                        el: div,
                        score: (hasSpanTitle ? 10 : 0) + (hasImg ? 5 : 0) + (div.scrollHeight / 100)
                    });
                }
            }
        }
    }
    
    // Ordenar por score y retornar el mejor
    if (candidates.length > 0) {
        candidates.sort((a, b) => b.score - a.score);
        console.log(`✅ Contenedor encontrado via búsqueda agresiva (${candidates.length} candidatos)`);
        return candidates[0].el;
    }
    
    console.error('❌ No se encontró contenedor de chats');
    console.log('💡 Intenta hacer scroll manual en la lista de chats y vuelve a intentar');
    return null;
}

// Buscar hijo scrollable dentro de un elemento
function findScrollableChild(parent) {
    if (!parent) return null;
    
    // Primero verificar si el parent mismo es scrollable
    if (parent.scrollHeight > parent.clientHeight + 50 && parent.clientHeight > 100) {
        return parent;
    }
    
    // Buscar en hijos directos
    for (const child of parent.children) {
        if (child.scrollHeight > child.clientHeight + 50 && child.clientHeight > 100) {
            const style = window.getComputedStyle(child);
            if (['auto', 'scroll', 'overlay'].includes(style.overflowY)) {
                return child;
            }
        }
    }
    
    // Buscar más profundo (hasta 3 niveles)
    const deepSearch = parent.querySelectorAll(':scope > div > div, :scope > div > div > div');
    for (const el of deepSearch) {
        if (el.scrollHeight > el.clientHeight + 50 && el.clientHeight > 100) {
            const style = window.getComputedStyle(el);
            if (['auto', 'scroll', 'overlay'].includes(style.overflowY)) {
                return el;
            }
        }
    }
    
    return null;
}

// ========================================
// FUNCIÓN: Extraer Contactos Visibles
// ========================================
function extractVisibleContacts(container) {
    const contacts = [];
    
    // Selectores para encontrar elementos de chat (orden de prioridad)
    const chatSelectors = [
        'div[role="listitem"]',
        'div[role="row"]',
        'div[role="option"]',
        '[data-testid="cell-frame-container"]',
        '[data-testid="list-item-content"]',
        '[data-testid*="listitem"]',
        '[data-testid*="chat"]'
    ];
    
    let chatElements = [];
    
    // Intentar con cada selector
    for (const selector of chatSelectors) {
        const elements = container.querySelectorAll(selector);
        if (elements.length > 0) {
            chatElements = Array.from(elements);
            console.log(`📋 Usando selector: ${selector} (${elements.length} elementos)`);
            break;
        }
    }
    
    // Si no encontramos con selectores, buscar elementos con span[title]
    if (chatElements.length === 0) {
        const titledSpans = container.querySelectorAll('span[title]');
        console.log(`📋 Buscando por span[title]: ${titledSpans.length} encontrados`);
        
        titledSpans.forEach(span => {
            // Subir hasta encontrar el contenedor del chat (3-5 niveles)
            let parent = span.parentElement;
            for (let i = 0; i < 5 && parent; i++) {
                if (parent.offsetHeight > 50 && parent.offsetHeight < 150) {
                    if (!chatElements.includes(parent)) {
                        chatElements.push(parent);
                    }
                    break;
                }
                parent = parent.parentElement;
            }
        });
    }
    
    // Si aún no hay elementos, buscar por estructura visual
    if (chatElements.length === 0) {
        console.log('📋 Búsqueda por estructura visual...');
        const allDivs = container.querySelectorAll('div');
        
        for (const div of allDivs) {
            const height = div.offsetHeight;
            const hasText = div.innerText && div.innerText.trim().length > 2;
            const hasAvatar = div.querySelector('img') || div.querySelector('[data-testid*="avatar"]');
            
            // Los chats típicamente tienen altura entre 60-90px
            if (height > 50 && height < 120 && hasText) {
                // Verificar que no es un hijo de otro elemento ya agregado
                const isChild = chatElements.some(el => el.contains(div));
                if (!isChild) {
                    chatElements.push(div);
                }
            }
        }
        
        // Limitar a los primeros 50 para no sobrecargar
        chatElements = chatElements.slice(0, 50);
    }
    
    console.log(`👥 Elementos de chat encontrados: ${chatElements.length}`);
    
    // Extraer información de cada chat
    const seenNames = new Set();
    
    chatElements.forEach(chat => {
        try {
            const contact = extractContactInfo(chat);
            if (contact && contact.name && !seenNames.has(contact.name)) {
                seenNames.add(contact.name);
                contacts.push(contact);
            }
        } catch (e) {
            // Ignorar errores individuales
        }
    });
    
    return contacts;
}

// ========================================
// FUNCIÓN: Extraer Info de un Contacto
// ========================================
function extractContactInfo(element) {
    if (!element || !element.innerText) return null;
    
    const text = element.innerText.trim();
    if (!text || text.length < 2) return null;
    
    // Obtener nombre
    let name = '';
    
    // Intentar con span[title]
    const titleSpan = element.querySelector('span[title]');
    if (titleSpan) {
        name = titleSpan.getAttribute('title') || titleSpan.textContent;
    }
    
    // Si no, usar la primera línea de texto
    if (!name) {
        const lines = text.split('\n').filter(l => l.trim());
        if (lines.length > 0) {
            name = lines[0].trim();
        }
    }
    
    if (!name || name.length < 2) return null;
    
    // Filtrar elementos del sistema
    const skipWords = [
        'archivados', 'archived', 'difusión', 'broadcast', 'nuevo', 'new',
        'ajustes', 'settings', 'comunidades', 'communities', 'canales', 'channels'
    ];
    
    const lowerName = name.toLowerCase();
    if (skipWords.some(word => lowerName === word || (name.length < 15 && lowerName.includes(word)))) {
        return null;
    }
    
    // Detectar si es número de teléfono
    let phone = '';
    const cleanedName = name.replace(/[\s\-\(\)\+]/g, '');
    if (/^\d{7,15}$/.test(cleanedName)) {
        phone = name;
    }
    
    // Obtener último mensaje
    let lastMessage = '';
    const lines = text.split('\n').filter(l => l.trim());
    if (lines.length > 1) {
        lastMessage = lines.slice(1).join(' ').substring(0, 150);
    }
    
    // Crear ID único
    const id = (phone || name).replace(/[\s\+\-\(\)]/g, '_').substring(0, 50);
    
    return {
        id: id,
        name: name.substring(0, 100),
        phone: phone,
        lastMessage: lastMessage,
        extractedAt: new Date().toISOString()
    };
}

// ========================================
// FUNCIÓN: Iniciar Extracción
// ========================================
async function startExtraction() {
    console.log('🚀 INICIANDO EXTRACCIÓN...');
    
    if (isScanning) {
        console.warn('⚠️ Ya hay una extracción en progreso');
        return { status: 'already_running' };
    }
    
    // Buscar contenedor
    const container = findChatContainer();
    
    if (!container) {
        console.error('❌ No se pudo encontrar la lista de chats');
        await chrome.storage.local.set({ 
            scanStatus: 'Error: Lista de chats no encontrada',
            isScanning: false 
        });
        return { status: 'error', error: 'container_not_found' };
    }
    
    isScanning = true;
    
    // Cargar contactos existentes
    const stored = await chrome.storage.local.get(['scrapedData']);
    if (stored.scrapedData && Array.isArray(stored.scrapedData)) {
        stored.scrapedData.forEach(c => extractedContacts.set(c.id, c));
        console.log(`📂 Cargados ${extractedContacts.size} contactos existentes`);
    }
    
    await chrome.storage.local.set({ 
        isScanning: true,
        scanStatus: 'Escaneando...'
    });
    
    console.log('✅ Contenedor encontrado. Iniciando escaneo automático...');
    
    let scrollCount = 0;
    let noNewContactsCount = 0;
    
    // Función de escaneo
    const scan = async () => {
        if (!isScanning) {
            console.log('⏹️ Escaneo detenido');
            return;
        }
        
        scrollCount++;
        const beforeCount = extractedContacts.size;
        
        // Extraer contactos visibles
        const newContacts = extractVisibleContacts(container);
        
        newContacts.forEach(contact => {
            if (!extractedContacts.has(contact.id)) {
                extractedContacts.set(contact.id, contact);
            }
        });
        
        const addedCount = extractedContacts.size - beforeCount;
        
        console.log(`📊 Scan #${scrollCount}: +${addedCount} nuevos, Total: ${extractedContacts.size}`);
        
        // Guardar progreso
        const contactsArray = Array.from(extractedContacts.values());
        await chrome.storage.local.set({
            scrapedData: contactsArray,
            totalContacts: contactsArray.length,
            scanStatus: `Escaneando... ${contactsArray.length} contactos`,
            lastScrollPosition: container.scrollTop,
            scanCycles: scrollCount
        });
        
        // Notificar al sidebar
        try {
            chrome.runtime.sendMessage({
                action: 'updateProgress',
                total: contactsArray.length,
                scrollCount: scrollCount
            });
        } catch (e) {
            // Sidebar puede no estar abierto
        }
        
        // Hacer scroll
        const scrollBefore = container.scrollTop;
        container.scrollTop += 400 + Math.random() * 200;
        
        // Verificar si llegamos al final
        if (addedCount === 0) {
            noNewContactsCount++;
        } else {
            noNewContactsCount = 0;
        }
        
        const atBottom = container.scrollTop >= container.scrollHeight - container.clientHeight - 50;
        
        if (noNewContactsCount >= 10 || (atBottom && noNewContactsCount >= 3)) {
            console.log('🏁 Extracción completada');
            await stopExtraction(true);
            return;
        }
        
        // Continuar después de delay
        const delay = 800 + Math.random() * 400;
        scanIntervalId = setTimeout(scan, delay);
    };
    
    // Iniciar primer scan
    scan();
    
    return { status: 'started' };
}

// ========================================
// FUNCIÓN: Detener Extracción
// ========================================
async function stopExtraction(completed = false) {
    console.log('⏹️ Deteniendo extracción...');
    
    isScanning = false;
    
    if (scanIntervalId) {
        clearTimeout(scanIntervalId);
        scanIntervalId = null;
    }
    
    const contactsArray = Array.from(extractedContacts.values());
    
    await chrome.storage.local.set({
        isScanning: false,
        scanStatus: completed ? `✓ Completado: ${contactsArray.length} contactos` : `Pausado: ${contactsArray.length} contactos`,
        scrapedData: contactsArray,
        totalContacts: contactsArray.length
    });
    
    // Notificar completado
    if (completed && contactsArray.length > 0) {
        try {
            chrome.runtime.sendMessage({
                action: 'extractionCompleted',
                contactCount: contactsArray.length
            });
        } catch (e) {
            // Sidebar puede no estar abierto
        }
    }
    
    return { status: 'stopped', contacts: contactsArray.length };
}

// ========================================
// FUNCIÓN: Limpiar Datos
// ========================================
async function clearData() {
    console.log('🗑️ Limpiando datos...');
    
    isScanning = false;
    extractedContacts.clear();
    
    if (scanIntervalId) {
        clearTimeout(scanIntervalId);
        scanIntervalId = null;
    }
    
    await chrome.storage.local.set({
        scrapedData: [],
        totalContacts: 0,
        isScanning: false,
        scanStatus: 'Listo',
        lastScrollPosition: 0,
        scanCycles: 0
    });
    
    return { status: 'cleared' };
}

// ========================================
// LISTENER DE MENSAJES
// ========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('📩 Mensaje recibido:', request.action);
    
    // Manejar cada acción
    switch(request.action) {
        case 'PING':
            sendResponse({ 
                success: true, 
                status: 'active',
                isScanning: isScanning,
                contactCount: extractedContacts.size
            });
            break;
            
        case 'START_SCRAPE':
            startExtraction().then(result => {
                sendResponse(result);
            });
            return true; // Mantener canal abierto para async
            
        case 'STOP_SCRAPE':
            stopExtraction(false).then(result => {
                sendResponse(result);
            });
            return true;
            
        case 'CLEAR_DATA':
            clearData().then(result => {
                sendResponse(result);
            });
            return true;
            
        case 'GET_STATUS':
            sendResponse({ 
                isScanning: isScanning,
                contactCount: extractedContacts.size,
                ready: document.querySelector('#pane-side') !== null || document.querySelector('#app') !== null
            });
            break;
            
        case 'checkWhatsAppStatus':
            const paneExists = document.querySelector('#pane-side') !== null;
            const appLoaded = document.querySelector('#app') !== null;
            sendResponse({ 
                isLoaded: paneExists || appLoaded,
                paneExists: paneExists,
                appLoaded: appLoaded
            });
            break;
            
        case 'RUN_DIAGNOSTICS':
            const diagnostics = runDiagnostics();
            sendResponse(diagnostics);
            break;
            
        default:
            console.warn('⚠️ Acción desconocida:', request.action);
            sendResponse({ status: 'unknown_action' });
    }
    
    return true;
});

// ========================================
// FUNCIÓN DE DIAGNÓSTICO
// ========================================
function runDiagnostics() {
    console.log('\n=== 🔍 DIAGNÓSTICO SNATCH EXPORTER ===\n');
    
    const results = {
        timestamp: new Date().toISOString(),
        contentScriptLoaded: true,
        whatsappDetected: false,
        containerFound: false,
        chatsVisible: 0
    };
    
    // 1. WhatsApp detectado?
    const app = document.querySelector('#app');
    const pane = document.querySelector('#pane-side');
    results.whatsappDetected = !!(app || pane);
    console.log(`1. WhatsApp detectado: ${results.whatsappDetected ? '✅' : '❌'}`);
    
    // 2. Contenedor encontrado?
    const container = findChatContainer();
    results.containerFound = !!container;
    console.log(`2. Contenedor de chats: ${results.containerFound ? '✅' : '❌'}`);
    
    if (container) {
        console.log(`   - scrollHeight: ${container.scrollHeight}`);
        console.log(`   - clientHeight: ${container.clientHeight}`);
    }
    
    // 3. Chats visibles?
    const listItems = document.querySelectorAll('div[role="listitem"]').length;
    const rows = document.querySelectorAll('div[role="row"]').length;
    const spanTitles = document.querySelectorAll('span[title]').length;
    results.chatsVisible = Math.max(listItems, rows);
    
    console.log(`3. Elementos encontrados:`);
    console.log(`   - role="listitem": ${listItems}`);
    console.log(`   - role="row": ${rows}`);
    console.log(`   - span[title]: ${spanTitles}`);
    
    // 4. Estado actual
    console.log(`4. Estado:`);
    console.log(`   - isScanning: ${isScanning}`);
    console.log(`   - contactos extraídos: ${extractedContacts.size}`);
    
    console.log('\n=== FIN DIAGNÓSTICO ===\n');
    
    return results;
}

// ========================================
// AUTO-RESUME AL RECARGAR
// ========================================
(async function autoResume() {
    try {
        const storage = await chrome.storage.local.get(['isScanning', 'scrapedData']);
        
        if (storage.scrapedData && Array.isArray(storage.scrapedData)) {
            storage.scrapedData.forEach(c => extractedContacts.set(c.id, c));
            console.log(`📂 Restaurados ${extractedContacts.size} contactos del storage`);
        }
        
        if (storage.isScanning) {
            console.log('🔄 Detectado escaneo previo, esperando para reanudar...');
            setTimeout(() => {
                if (document.querySelector('#pane-side') || document.querySelector('#app')) {
                    console.log('🔄 Reanudando extracción...');
                    startExtraction();
                }
            }, 3000);
        }
    } catch (e) {
        console.error('Error en auto-resume:', e);
    }
})();

// ========================================
// EXPONER FUNCIONES PARA DEBUG
// ========================================
window.snatchExporter = {
    startExtraction,
    stopExtraction,
    clearData,
    runDiagnostics,
    findChatContainer,
    getContacts: () => Array.from(extractedContacts.values()),
    getStatus: () => ({ isScanning, contactCount: extractedContacts.size })
};

console.log('✅ Snatch Exporter listo. Usa window.snatchExporter para debug.');
console.log('   Ejecuta runDiagnostics() para ver el estado.');
